//Created by Piotr Kurzynoga @ Oracle Czech Republic
//Copyright (c) 2025, Oracle and/or its affiliates.
//Licensed under the Universal Permissive License v1.0 as shown at https://oss.oracle.com/licenses/upl.

package main

import (
	"context"
	"database/sql"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"reflect"
	"strconv"

	"github.com/gorilla/mux"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/oracle/oci-go-sdk/v65/common"
	"github.com/oracle/oci-go-sdk/v65/common/auth"
	"github.com/oracle/oci-go-sdk/v65/secrets"
	"github.com/rs/cors"
)

// Model for vehicle
type Vehicle struct {
	Vehicle_id         int     `json:"vehicle_id"`
	Latitude           float64 `json:"latitude"`
	Longitude          float64 `json:"longitude"`
	Tire_pressure      float64 `json:"tire_pressure"`
	Fuel_level         float64 `json:"fuel_level"`
	Driver_heartbeats  int     `json:"driver_heartbeats"`
	Engine_temperature float64 `json:"engine_temperature"`
	Battery_surplus    float64 `json:"battery_surplus"`
	Oil_surplus        float64 `json:"oil_surplus"`
	Engine_rpm         int     `json:"engine_rpm"`
}

// OCI Auth
var configProvider common.ConfigurationProvider

// OCI Regions
var current_region = ""
var primary_region = ""
var standby_region = ""

// PostgreSQL Secret OCID
var primary_secretOCID = ""
var standby_secretOCID = ""

// Database connection
var psql *sql.DB

var postgreSQL = map[string]string{
	"user":     "",
	"database": "",
	"password": "",
	"host":     "",
	"port":     "5432",
	"sslmode":  "require",
}

func PostgresConnection(dbParams map[string]string) *sql.DB {
	dsn := fmt.Sprintf(
		"user=%s password=%s host=%s port=%s dbname=%s sslmode=%s",
		dbParams["user"],
		dbParams["password"],
		dbParams["host"],
		dbParams["port"],
		dbParams["database"],
		dbParams["sslmode"],
	)
	db, err := sql.Open("pgx", dsn)
	if err != nil {
		panic(fmt.Errorf("error in sql.Open: %w", err))
	}
	err = db.Ping()
	if err != nil {
		panic(fmt.Errorf("error pinging db: %w", err))
	}
	return db
}

func init() {
	//Check if secrets are configured
	if primary_secretOCID == "" || standby_secretOCID == "" {
		fmt.Println("primary or standby secret variable not set")
		os.Exit(1)
	}

	//Configure instance principal authentication
	var err error
	configProvider, err = auth.InstancePrincipalConfigurationProvider()
	if err != nil {
		log.Fatalf("Failed to get instance principal provider: %v", err)
	}

	//Check current region
	var secretValue = ""
	current_region, err = GetRegion()

	if current_region == primary_region {
		secretValue, err = GetSecretValueFromVault(primary_secretOCID)
		if err != nil {
			fmt.Printf("Error retrieving secret: %v\n", err)
			os.Exit(1)
		}
	} else if current_region == standby_region {
		secretValue, err = GetSecretValueFromVault(standby_secretOCID)
		if err != nil {
			fmt.Printf("Error retrieving secret: %v\n", err)
			os.Exit(1)
		}
	} else {
		log.Fatalf("The instance is not in the correct region.")
	}

	postgreSQL["password"] = secretValue
	fmt.Println("Postgres password set using Secret.")

	psql = PostgresConnection(postgreSQL)
	fmt.Println("Postgres DB Connection Started")

}

func main() {
	router := mux.NewRouter()

	// User API Endpoints
	router.HandleFunc("/vehicles", getVehicles).Methods("GET", "OPTIONS")

	// Allow CORS for any origins
	handler := cors.New(cors.Options{
		//AllowedOrigins: []string{"http://localhost:3000"}, (Optional to confine to local env)
		AllowedHeaders:   ([]string{"Access-Control-Allow-Headers", "Origin", "Accept", "X-Requested-With", "Content-Type", "Access-Control-Request-Method", "Access-Control-Request-Headers"}),
		AllowedOrigins:   ([]string{"*"}),
		AllowedMethods:   ([]string{"GET", "POST", "OPTIONS", "DELETE", "PUT"}),
		AllowCredentials: true,
		Debug:            false,
	}).Handler(router)

	fmt.Printf("Server listening on port 8585\n")
	log.Fatal(http.ListenAndServe(":8585", handler))
}

// Get all Vehicles
func getVehicles(w http.ResponseWriter, r *http.Request) {
	var vehicles []Vehicle
	rows, err := psql.Query("SELECT distinct on (vehicle_id) vehicle_id, latitude, longitude, fuel_level, tire_pressure, engine_rpm, oil_surplus, battery_surplus, engine_temperature, driver_heartbeats FROM iot.cars")
	if err != nil {
		log.Fatal(err)
	}
	//rows := psql.QueryRow("select * from users where id=1")
	for rows.Next() {
		var vehicle Vehicle
		err := rows.Scan(&vehicle.Vehicle_id, &vehicle.Latitude, &vehicle.Longitude, &vehicle.Fuel_level, &vehicle.Tire_pressure, &vehicle.Engine_rpm, &vehicle.Oil_surplus, &vehicle.Battery_surplus, &vehicle.Engine_temperature, &vehicle.Driver_heartbeats)
		handleError("query row", err)
		if err != nil {
			panic(fmt.Errorf("error scanning db: %w", err))
		}
		//fmt.Println(vehicle)
		vehicles = append(vehicles, vehicle)
	}

	json.NewEncoder(w).Encode(vehicles)
	//fmt.Println(vehicles)
}

// Error handling function.
func handleError(msg string, err error) {
	if err != nil {
		fmt.Println(msg, err)
		//os.Exit(1)
	}
}

// EncodeFloats takes a struct and returns a map where float64 fields are converted to string
func EncodeFloats(v interface{}) (map[string]string, error) {
	result := make(map[string]string)

	// Use reflection to iterate over struct fields
	val := reflect.ValueOf(v)
	if val.Kind() == reflect.Ptr {
		val = val.Elem()
	}

	// Make sure we're working with a struct
	if val.Kind() != reflect.Struct {
		return nil, fmt.Errorf("expected a struct, but got %T", v)
	}

	// Iterate through the struct fields
	for i := 0; i < val.NumField(); i++ {
		field := val.Field(i)
		fieldType := val.Type().Field(i)
		fieldName := fieldType.Name

		// Only encode float64 fields
		if field.Kind() == reflect.Float64 {
			// Convert float64 to string and add to result map
			result[fieldName] = strconv.FormatFloat(field.Float(), 'f', 6, 64)
		}
	}

	return result, nil
}

// Return the current OCI Region for Instance Principal
func GetRegion() (string, error) {
	//Using instance principal
	current_region, err := configProvider.Region()
	if err != nil {
		return "", fmt.Errorf("error getting region: %w", err)
	}
	fmt.Printf("Currently in Region: %s\n", current_region)

	return current_region, nil
}

// GetSecretValueFromVault retrieves a secret from OCI Vault using API key-based authentication
func GetSecretValueFromVault(secretOCID string) (string, error) {
	// Create a SecretsClient
	client, err := secrets.NewSecretsClientWithConfigurationProvider(configProvider)
	if err != nil {
		return "", fmt.Errorf("error creating secrets client: %w", err)
	}

	// Prepare GetSecretBundle request
	request := secrets.GetSecretBundleRequest{
		SecretId: &secretOCID,
	}

	// Make the API call
	response, err := client.GetSecretBundle(context.Background(), request)
	if err != nil {
		return "", fmt.Errorf("error getting secret bundle: %w", err)
	}

	// Extract and decode the base64 content
	contentDetails, ok := response.SecretBundle.SecretBundleContent.(secrets.Base64SecretBundleContentDetails)
	if !ok {
		return "", fmt.Errorf("unexpected content format")
	}

	decoded, err := base64.StdEncoding.DecodeString(*contentDetails.Content)
	if err != nil {
		return "", fmt.Errorf("error decoding base64 secret: %w", err)
	}

	return string(decoded), nil
}
